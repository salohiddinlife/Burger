const product = {
    crazy: {
        name: 'Crazy',
        price: 31000,
        amount: 0,
        get totalsum() {
            return this.price * this.amount;
        }
    },
    light: {
        name: 'Light',
        price: 26000,
        amount: 0,
        get totalsum() {
            return this.price * this.amount;
        }
    },
    cheeseburger: {
        name: 'CheeseBurger',
        price: 29000,
        amount: 0,
        get totalsum() {
            return this.price * this.amount;
        }
    },
    dburger: {
        name: 'dBurger',
        price: 24000,
        amount: 0,
        get totalsum() {
            return this.price * this.amount;
        }
    }
};

const cart = document.querySelector('.wrapper__navbar-basket'),
      cartbtn = document.querySelector('.wrapper__navbar-btn'),
      cartclose = document.querySelector('.wrapper__navbar-close'),
      addProduct = document.querySelectorAll('.wrapper__list-btn'),
      checklist = document.querySelector('.wrapper__navbar-checklist'),
      cardCount = document.querySelectorAll('.wrapper__list-count'),
      cartcount = document.querySelector('.warapper__navbar-count')
;
      

cartbtn.addEventListener('click', function () {
    cart.classList.toggle('active')
})
cartclose.addEventListener('click', function(){
    cart.classList.remove('active')
})

productBtn.forEach(btn => {
    btn.addEventListener('click', function () {
        plusOrMinus(this);
        updateBasket();
    });
});
function plusOrMinus(btn) {
    let parent = btn.closest('.wrapper__list-card'),
        parentId = parent.getAttribute('id');
    product[parentId].amount++;
    basket();
}
